#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.


rqmoments<-function (x,dtype1=1,releaseall=FALSE,standist_d=NULL,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,interval=8,batch="auto",stepsize=1000,criterion=1e-30,boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

  lengthx<-length(sortedx)

  if(lengthx>40 || boot){
    if(is.null(orderlist1_sorted2)||is.null(orderlist1_sorted3)||is.null(orderlist1_sorted4)){
      data(quasiuni_2_104)
      data(quasiuni_3_104)
      data(quasiuni_4_104)
      orderlist1_sorted2<-createorderlist(quni1=quasiuni_2_104,size=lengthx,interval=8,dimension=2)
      orderlist1_sorted3<-createorderlist(quni1=quasiuni_3_104,size=lengthx,interval=8,dimension=3)
      orderlist1_sorted4<-createorderlist(quni1=quasiuni_4_104,size=lengthx,interval=8,dimension=4)
    }
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)

    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample2<-c()

    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted3,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample3<-c()

    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted4,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))

    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample2<-c()

    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))

    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample3<-c()

    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))

    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample4<-c()

  }

  mmm1raw<-mmmraw(x=sortedx,interval=interval,batch=batch,sorted=TRUE)

  varmoraw<-mmmraw(x=dp2varx,interval=interval,batch=batch,sorted=TRUE)

  tmmoraw<-mmmraw(x=dp3tmx,interval=interval,batch=batch,sorted=TRUE)

  fmmoraw<-mmmraw(x=dp4fmx,interval=interval,batch=batch,sorted=TRUE)

  if(is.null(standist_d)){
    data(d_SWA)
    standist_d=as.data.frame(d_SWA)
  }
  #exponential
  estimators_rm<-function(meantype,vartype,tmtype,fmtype,type11=1){
    #exp
    start_kurt=9
    start_skew=2

    mean_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=meantype)
    var_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d,etype=vartype)

    var_drm2<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=vartype)

    tm_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=tmtype)
    fm_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d,etype=fmtype)

    mmm1_rm_exp1<-mmmprocessrm(x=sortedx,interval=interval,SWA=mmm1raw[type11+1],median=mmm1raw[8],mx1=mmm1raw[type11+8],drm=mean_drm1)
    varmo_rm_exp1<-mmmprocessrm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],drm=var_drm1)
    varmo_rm_exp2<-mmmprocessrm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],drm=var_drm2)

    tmmo_rm_exp1<-mmmprocessrm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],drm=tm_drm1)

    fmmo_rm_exp1<-mmmprocessrm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],drm=fm_drm1)

    #two parameter

    kurt1<-26

    skew1<-3.68267203509023

    Kappa1<-function(kurt1){
      var_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vartype)

      fm_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmtype)

      varmo_rm_two1<-mmmprocessrm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],drm=var_drm1)

      fmmo_rm_two1<-mmmprocessrm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],drm=fm_drm1)

      ((fmmo_rm_two1))/(varmo_rm_two1^2)
    }
    step1 <- 0

    repeat {
      step1 <-step1 + 1

      kurt2<-Kappa1(kurt1)

      if ((abs(kurt1-kurt2))<criterion || (step1 == stepsize)){

        break
      }
      kurt1<-kurt2
    }

    Skewness1<-function(skew1){
      var_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=vartype)

      tm_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmtype)

      varmo_rm_two1<-mmmprocessrm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],drm=var_drm1)

      tmmo_rm_two1<-mmmprocessrm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],drm=tm_drm1)

      ((tmmo_rm_two1))/(varmo_rm_two1^(3/2))
    }
    step1 <- 0

    repeat {
      step1 <-step1 + 1

      skew2<-Skewness1(skew1)

      if ((abs(skew1-skew2))<criterion || (step1 == stepsize)){

        break
      }
      skew1<-skew2
    }

    mean_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=meantype)
    var_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vartype)

    tm_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmtype)
    fm_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmtype)

    mmm1_rm_two1<-mmmprocessrm(x=sortedx,interval=interval,SWA=mmm1raw[type11+1],median=mmm1raw[8],mx1=mmm1raw[type11+8],drm=mean_drm1)

    varmo_rm_two1<-mmmprocessrm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],drm=var_drm1)

    tmmo_rm_two1<-mmmprocessrm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],drm=tm_drm1)

    fmmo_rm_two1<-mmmprocessrm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],drm=fm_drm1)

    allresults<-c(mmm1_rm_exp1=mmm1_rm_exp1,
                  varmo_rm_exp1=varmo_rm_exp1,
                  tmmo_rm_exp1=tmmo_rm_exp1,
                  fmmo_rm_exp1=fmmo_rm_exp1,
                  mmm1_rm_two1=mmm1_rm_two1,
                  varmo_rm_two1=varmo_rm_two1,
                  tmmo_rm_two1=tmmo_rm_two1,
                  fmmo_rm_two1=fmmo_rm_two1
    )
    return(allresults)
  }

  estimators_qm<-function(meantype,vartype,tmtype,fmtype,type11=1){

    #exp

    start_kurt=9
    start_skew=2

    mean_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=meantype)
    var_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d,etype=vartype)

    var_dqm2<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=vartype)

    tm_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=tmtype)
    fm_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d,etype=fmtype)

    mmm1_qm_exp1<-mmmprocessqm(x=sortedx,interval=interval,SWA=mmm1raw[type11+1],median=mmm1raw[8],mx1=mmm1raw[type11+8],dqm=mean_dqm1)
    varmo_qm_exp1<-mmmprocessqm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],dqm=var_dqm1)
    varmo_qm_exp2<-mmmprocessqm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],dqm=var_dqm2)

    tmmo_qm_exp1<-mmmprocessqm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],dqm=tm_dqm1)

    fmmo_qm_exp1<-mmmprocessqm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],dqm=fm_dqm1)

    #two parameter

    kurt1<-26

    skew1<-3.68267203509023

    Kappa1<-function(kurt1){
      var_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vartype)

      fm_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmtype)

      varmo_qm_two1<-mmmprocessqm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],dqm=var_dqm1)

      fmmo_qm_two1<-mmmprocessqm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],dqm=fm_dqm1)

      ((fmmo_qm_two1))/(varmo_qm_two1^2)
    }
    step1 <- 0

    repeat {
      step1 <-step1 + 1

      kurt2<-Kappa1(kurt1)

      if ((abs(kurt1-kurt2))<criterion || (step1 == stepsize)){

        break
      }
      kurt1<-kurt2
    }

    Skewness1<-function(skew1){
      var_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=vartype)

      tm_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmtype)

      varmo_qm_two1<-mmmprocessqm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],dqm=var_dqm1)

      tmmo_qm_two1<-mmmprocessqm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],dqm=tm_dqm1)

      ((tmmo_qm_two1))/(varmo_qm_two1^(3/2))
    }
    step1 <- 0

    repeat {
      step1 <-step1 + 1

      skew2<-Skewness1(skew1)

      if ((abs(skew1-skew2))<criterion || (step1 == stepsize)){

        break
      }
      skew1<-skew2
    }

    mean_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=meantype)
    var_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vartype)

    tm_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmtype)
    fm_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmtype)

    mmm1_qm_two1<-mmmprocessqm(x=sortedx,interval=interval,SWA=mmm1raw[type11+1],median=mmm1raw[8],mx1=mmm1raw[type11+8],dqm=mean_dqm1)

    varmo_qm_two1<-mmmprocessqm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],dqm=var_dqm1)

    tmmo_qm_two1<-mmmprocessqm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],dqm=tm_dqm1)

    fmmo_qm_two1<-mmmprocessqm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],dqm=fm_dqm1)

    check1<-function(x, requirement) {
      x <- ifelse(names(x) == requirement,NA,x)
      return(x)
    }

    allresults_exp<-c(mmm1_qm_exp1=check1(x=mmm1_qm_exp1,requirement="qm.0.875"),
                      varmo_qm_exp1=check1(x=varmo_qm_exp1,requirement="qm.0.875"),
                      tmmo_qm_exp1=check1(x=tmmo_qm_exp1,requirement="qm.0.875"),
                      fmmo_qm_exp1=check1(x=fmmo_qm_exp1,requirement="qm.0.875"))

    if (names(mmm1_qm_two1) == "qm.0.875"||names(varmo_qm_two1) == "qm.0.875"||names(tmmo_qm_two1) == "qm.0.875"||names(fmmo_qm_two1) == "qm.0.875"){
      allresults_two<-c(mmm1_qm_two1=NA,
                        varmo_qm_two1=NA,
                        tmmo_qm_two1=NA,
                        fmmo_qm_two1=NA)
    }else{
      allresults_two<-c(mmm1_qm_two1=mmm1_qm_two1,
                            varmo_qm_two1=varmo_qm_two1,
                            tmmo_qm_two1=tmmo_qm_two1,
                            fmmo_qm_two1=fmmo_qm_two1)
    }
    allresults<-c(allresults_exp,allresults_two)

    return(allresults)
  }

  BM38_rm1<-estimators_rm(meantype="mean_BM38_drm",vartype="var_BM38_drm",tmtype="tm_BM38_drm",fmtype="fm_BM38_drm",type11 = 1)

  BM38_qm1<-estimators_qm(meantype="mean_BM38_dqm",vartype="var_BM38_dqm",tmtype="tm_BM38_dqm",fmtype="fm_BM38_dqm",type11 = 1)

  sqm8_rm1<-estimators_rm(meantype="mean_sqm8_drm",vartype="var_sqm8_drm",tmtype="tm_sqm8_drm",fmtype="fm_sqm8_drm",type11 = 2)

  sqm8_qm1<-estimators_qm(meantype="mean_sqm8_dqm",vartype="var_sqm8_dqm",tmtype="tm_sqm8_dqm",fmtype="fm_sqm8_dqm",type11 = 2)

  BM28_rm1<-estimators_rm(meantype="mean_BM28_drm",vartype="var_BM28_drm",tmtype="tm_BM28_drm",fmtype="fm_BM28_drm",type11 = 3)

  BM28_qm1<-estimators_qm(meantype="mean_BM28_dqm",vartype="var_BM28_dqm",tmtype="tm_BM28_dqm",fmtype="fm_BM28_dqm",type11 = 3)

  wm8_rm1<-estimators_rm(meantype="mean_wm8_drm",vartype="var_wm8_drm",tmtype="tm_wm8_drm",fmtype="fm_wm8_drm",type11 = 4)

  wm8_qm1<-estimators_qm(meantype="mean_wm8_dqm",vartype="var_wm8_dqm",tmtype="tm_wm8_dqm",fmtype="fm_wm8_dqm",type11 = 4)

  bwm8_rm1<-estimators_rm(meantype="mean_bwm8_drm",vartype="var_bwm8_drm",tmtype="tm_bwm8_drm",fmtype="fm_bwm8_drm",type11 = 5)

  bwm8_qm1<-estimators_qm(meantype="mean_bwm8_dqm",vartype="var_bwm8_dqm",tmtype="tm_bwm8_dqm",fmtype="fm_bwm8_dqm",type11 = 5)

  tm8_rm1<-estimators_rm(meantype="mean_tm8_drm",vartype="var_tm8_drm",tmtype="tm_tm8_drm",fmtype="fm_tm8_drm",type11 = 6)

  tm8_qm1<-estimators_qm(meantype="mean_tm8_dqm",vartype="var_tm8_dqm",tmtype="tm_tm8_dqm",fmtype="fm_tm8_dqm",type11 = 6)

  sdall<-c(sdvar=sd(dp2varx),sdtm=sd(dp3tmx),sdfm=sd(dp4fmx))

  allresults1<-c(BM38_rm1=BM38_rm1,BM38_qm1=BM38_qm1,sqm8_rm1=sqm8_rm1,sqm8_qm1=sqm8_qm1,BM28_rm1=BM28_rm1,BM28_qm1=BM28_qm1,wm8_rm1=wm8_rm1,wm8_qm1=wm8_qm1,bwm8_rm1=bwm8_rm1,bwm8_qm1=bwm8_qm1,tm8_rm1=tm8_rm1,tm8_qm1=tm8_qm1)
  if(releaseall){
    finallall<-c(mmm1raw=mmm1raw,
                 varmoraw=varmoraw,
                 tmmoraw=tmmoraw,
                 fmmoraw=fmmoraw,
                 sdall=sdall)
    return(c(allresults1,finallall))
  }else{
    return(c(allresults1))
  }
}

imoments<-function (x,dtype1=1,releaseall=FALSE,standist_d=NULL,standist_I=NULL,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,interval=8,batch="auto",stepsize=1000,criterion=1e-30,boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

  lengthx<-length(sortedx)

  if(lengthx>40 || boot){
    if(is.null(orderlist1_sorted2)||is.null(orderlist1_sorted3)||is.null(orderlist1_sorted4)){
      data(quasiuni_2_104)
      data(quasiuni_3_104)
      data(quasiuni_4_104)
      orderlist1_sorted2<-createorderlist(quni1=quasiuni_2_104,size=lengthx,interval=8,dimension=2)
      orderlist1_sorted3<-createorderlist(quni1=quasiuni_3_104,size=lengthx,interval=8,dimension=3)
      orderlist1_sorted4<-createorderlist(quni1=quasiuni_4_104,size=lengthx,interval=8,dimension=4)
    }
    bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)

    dp2varx<-varapply1(bootstrappedsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample2<-c()

    bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted3,sortedx=sortedx,dimension=3)
    dp3tmx<-tmapply1(bootstrappedsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample3<-c()

    bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted4,sortedx=sortedx,dimension=4)
    dp4fmx<-fmapply1(bootstrappedsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    bootstrappedsample4<-c()
  }else{
    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))

    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample2<-c()

    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))

    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample3<-c()

    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))

    dp4fmx<-fmapply1(combinationsample4)
    dp4fmx<-Rfast::Sort(x=dp4fmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

    combinationsample4<-c()

  }

  mmm1raw<-mmmraw(x=sortedx,interval=interval,batch=batch,sorted=TRUE)

  varmoraw<-mmmraw(x=dp2varx,interval=interval,batch=batch,sorted=TRUE)

  tmmoraw<-mmmraw(x=dp3tmx,interval=interval,batch=batch,sorted=TRUE)

  fmmoraw<-mmmraw(x=dp4fmx,interval=interval,batch=batch,sorted=TRUE)

  if(is.null(standist_d)){
    data(d_SWA)
    standist_d=as.data.frame(d_SWA)
  }
  #exponential
  estimators_rm<-function(meantype,vartype,tmtype,fmtype,type11=1){
    #exp
    start_kurt=9
    start_skew=2

    mean_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=meantype)
    var_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d,etype=vartype)

    var_drm2<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=vartype)

    tm_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=tmtype)
    fm_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d,etype=fmtype)

    mmm1_rm_exp1<-mmmprocessrm(x=sortedx,interval=interval,SWA=mmm1raw[type11+1],median=mmm1raw[8],mx1=mmm1raw[type11+8],drm=mean_drm1)
    varmo_rm_exp1<-mmmprocessrm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],drm=var_drm1)
    varmo_rm_exp2<-mmmprocessrm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],drm=var_drm2)

    tmmo_rm_exp1<-mmmprocessrm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],drm=tm_drm1)

    fmmo_rm_exp1<-mmmprocessrm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],drm=fm_drm1)

    #two parameter

    kurt1<-26

    skew1<-3.68267203509023

    Kappa1<-function(kurt1){
      var_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vartype)

      fm_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmtype)

      varmo_rm_two1<-mmmprocessrm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],drm=var_drm1)

      fmmo_rm_two1<-mmmprocessrm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],drm=fm_drm1)

      ((fmmo_rm_two1))/(varmo_rm_two1^2)
    }
    step1 <- 0

    repeat {
      step1 <-step1 + 1

      kurt2<-Kappa1(kurt1)

      if ((abs(kurt1-kurt2))<criterion || (step1 == stepsize)){

        break
      }
      kurt1<-kurt2
    }

    Skewness1<-function(skew1){
      var_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=vartype)

      tm_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmtype)

      varmo_rm_two1<-mmmprocessrm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],drm=var_drm1)

      tmmo_rm_two1<-mmmprocessrm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],drm=tm_drm1)

      ((tmmo_rm_two1))/(varmo_rm_two1^(3/2))
    }
    step1 <- 0

    repeat {
      step1 <-step1 + 1

      skew2<-Skewness1(skew1)

      if ((abs(skew1-skew2))<criterion || (step1 == stepsize)){

        break
      }
      skew1<-skew2
    }

    mean_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=meantype)
    var_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vartype)

    tm_drm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmtype)
    fm_drm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmtype)

    mmm1_rm_two1<-mmmprocessrm(x=sortedx,interval=interval,SWA=mmm1raw[type11+1],median=mmm1raw[8],mx1=mmm1raw[type11+8],drm=mean_drm1)

    varmo_rm_two1<-mmmprocessrm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],drm=var_drm1)

    tmmo_rm_two1<-mmmprocessrm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],drm=tm_drm1)

    fmmo_rm_two1<-mmmprocessrm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],drm=fm_drm1)

    allresults<-c(mmm1_rm_exp1=mmm1_rm_exp1,
                  varmo_rm_exp1=varmo_rm_exp1,
                  tmmo_rm_exp1=tmmo_rm_exp1,
                  fmmo_rm_exp1=fmmo_rm_exp1,
                  mmm1_rm_two1=mmm1_rm_two1,
                  varmo_rm_two1=varmo_rm_two1,
                  tmmo_rm_two1=tmmo_rm_two1,
                  fmmo_rm_two1=fmmo_rm_two1
    )
    return(allresults)
  }

  estimators_qm<-function(meantype,vartype,tmtype,fmtype,type11=1){

    #exp

    start_kurt=9
    start_skew=2

    mean_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=meantype)
    var_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d,etype=vartype)

    var_dqm2<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=vartype)

    tm_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,dlist=standist_d,etype=tmtype)
    fm_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,dlist=standist_d,etype=fmtype)

    mmm1_qm_exp1<-mmmprocessqm(x=sortedx,interval=interval,SWA=mmm1raw[type11+1],median=mmm1raw[8],mx1=mmm1raw[type11+8],dqm=mean_dqm1)
    varmo_qm_exp1<-mmmprocessqm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],dqm=var_dqm1)
    varmo_qm_exp2<-mmmprocessqm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],dqm=var_dqm2)

    tmmo_qm_exp1<-mmmprocessqm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],dqm=tm_dqm1)

    fmmo_qm_exp1<-mmmprocessqm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],dqm=fm_dqm1)

    #two parameter

    kurt1<-26

    skew1<-3.68267203509023

    Kappa1<-function(kurt1){
      var_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vartype)

      fm_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmtype)

      varmo_qm_two1<-mmmprocessqm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],dqm=var_dqm1)

      fmmo_qm_two1<-mmmprocessqm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],dqm=fm_dqm1)

      ((fmmo_qm_two1))/(varmo_qm_two1^2)
    }
    step1 <- 0

    repeat {
      step1 <-step1 + 1

      kurt2<-Kappa1(kurt1)

      if ((abs(kurt1-kurt2))<criterion || (step1 == stepsize)){

        break
      }
      kurt1<-kurt2
    }

    Skewness1<-function(skew1){
      var_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=vartype)

      tm_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmtype)

      varmo_qm_two1<-mmmprocessqm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],dqm=var_dqm1)

      tmmo_qm_two1<-mmmprocessqm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],dqm=tm_dqm1)

      ((tmmo_qm_two1))/(varmo_qm_two1^(3/2))
    }
    step1 <- 0

    repeat {
      step1 <-step1 + 1

      skew2<-Skewness1(skew1)

      if ((abs(skew1-skew2))<criterion || (step1 == stepsize)){

        break
      }
      skew1<-skew2
    }

    mean_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=meantype)
    var_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=vartype)

    tm_dqm1<-d_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,dlist=standist_d,etype=tmtype)
    fm_dqm1<-d_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,dlist=standist_d,etype=fmtype)

    mmm1_qm_two1<-mmmprocessqm(x=sortedx,interval=interval,SWA=mmm1raw[type11+1],median=mmm1raw[8],mx1=mmm1raw[type11+8],dqm=mean_dqm1)

    varmo_qm_two1<-mmmprocessqm(x=dp2varx,interval=interval,SWA=varmoraw[type11+1],median=varmoraw[8],mx1=varmoraw[type11+8],dqm=var_dqm1)

    tmmo_qm_two1<-mmmprocessqm(x=dp3tmx,interval=interval,SWA=tmmoraw[type11+1],median=tmmoraw[8],mx1=tmmoraw[type11+8],dqm=tm_dqm1)

    fmmo_qm_two1<-mmmprocessqm(x=dp4fmx,interval=interval,SWA=fmmoraw[type11+1],median=fmmoraw[8],mx1=fmmoraw[type11+8],dqm=fm_dqm1)

    allresults_exp<-c(mmm1_qm_exp1=mmm1_qm_exp1,
                      varmo_qm_exp1=varmo_qm_exp1,
                      tmmo_qm_exp1=tmmo_qm_exp1,
                      fmmo_qm_exp1=fmmo_qm_exp1)

    allresults_two<-c(mmm1_qm_two1=mmm1_qm_two1,
                      varmo_qm_two1=varmo_qm_two1,
                      tmmo_qm_two1=tmmo_qm_two1,
                      fmmo_qm_two1=fmmo_qm_two1)
    allresults<-c(allresults_exp,allresults_two)

    return(allresults)
  }

  BM38_rm1<-estimators_rm(meantype="mean_BM38_drm",vartype="var_BM38_drm",tmtype="tm_BM38_drm",fmtype="fm_BM38_drm",type11 = 1)

  BM38_qm1<-estimators_qm(meantype="mean_BM38_dqm",vartype="var_BM38_dqm",tmtype="tm_BM38_dqm",fmtype="fm_BM38_dqm",type11 = 1)

  sqm8_rm1<-estimators_rm(meantype="mean_sqm8_drm",vartype="var_sqm8_drm",tmtype="tm_sqm8_drm",fmtype="fm_sqm8_drm",type11 = 2)

  sqm8_qm1<-estimators_qm(meantype="mean_sqm8_dqm",vartype="var_sqm8_dqm",tmtype="tm_sqm8_dqm",fmtype="fm_sqm8_dqm",type11 = 2)

  BM28_rm1<-estimators_rm(meantype="mean_BM28_drm",vartype="var_BM28_drm",tmtype="tm_BM28_drm",fmtype="fm_BM28_drm",type11 = 3)

  BM28_qm1<-estimators_qm(meantype="mean_BM28_dqm",vartype="var_BM28_dqm",tmtype="tm_BM28_dqm",fmtype="fm_BM28_dqm",type11 = 3)

  wm8_rm1<-estimators_rm(meantype="mean_wm8_drm",vartype="var_wm8_drm",tmtype="tm_wm8_drm",fmtype="fm_wm8_drm",type11 = 4)

  wm8_qm1<-estimators_qm(meantype="mean_wm8_dqm",vartype="var_wm8_dqm",tmtype="tm_wm8_dqm",fmtype="fm_wm8_dqm",type11 = 4)

  bwm8_rm1<-estimators_rm(meantype="mean_bwm8_drm",vartype="var_bwm8_drm",tmtype="tm_bwm8_drm",fmtype="fm_bwm8_drm",type11 = 5)

  bwm8_qm1<-estimators_qm(meantype="mean_bwm8_dqm",vartype="var_bwm8_dqm",tmtype="tm_bwm8_dqm",fmtype="fm_bwm8_dqm",type11 = 5)

  tm8_rm1<-estimators_rm(meantype="mean_tm8_drm",vartype="var_tm8_drm",tmtype="tm_tm8_drm",fmtype="fm_tm8_drm",type11 = 6)

  tm8_qm1<-estimators_qm(meantype="mean_tm8_dqm",vartype="var_tm8_dqm",tmtype="tm_tm8_dqm",fmtype="fm_tm8_dqm",type11 = 6)

  sdall<-c(sdvar=sd(dp2varx),sdtm=sd(dp3tmx),sdfm=sd(dp4fmx))

  allresults1<-c(BM38_rm1=BM38_rm1,BM38_qm1=BM38_qm1,sqm8_rm1=sqm8_rm1,sqm8_qm1=sqm8_qm1,BM28_rm1=BM28_rm1,BM28_qm1=BM28_qm1,wm8_rm1=wm8_rm1,wm8_qm1=wm8_qm1,bwm8_rm1=bwm8_rm1,bwm8_qm1=bwm8_qm1,tm8_rm1=tm8_rm1,tm8_qm1=tm8_qm1)

  meanallselectexp<-allresults1[seq(from=1, to=96, by=8)]

  varallselectexp<-allresults1[seq(from=2, to=96, by=8)]

  tmallselectexp<-allresults1[seq(from=3, to=96, by=8)]

  fmallselectexp<-allresults1[seq(from=4, to=96, by=8)]

  meanallselectWeibull<-allresults1[seq(from=5, to=96, by=8)]

  varallselectWeibull<-allresults1[seq(from=6, to=96, by=8)]

  tmallselectWeibull<-allresults1[seq(from=7, to=96, by=8)]

  fmallselectWeibull<-allresults1[seq(from=8, to=96, by=8)]
  if(is.null(standist_I)){
    data(I_SWA)
    standist_I=as.data.frame(I_SWA)
  }

  #exp
  start_kurt=9
  start_skew=2

  if(lengthx!=5400&lengthx!=1.8*10^6){
    lengthx=5400
  }

  mean_BM_I<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,Ilist=standist_I,etype="mean_AB_exp")
  var_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,Ilist=standist_I,etype="var_AB_exp")
  tm_BM_I<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,Ilist=standist_I,etype="tm_AB_exp")
  fm_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,Ilist=standist_I,etype="fm_AB_exp")

  meanmo_adaptive_AB_exp<-meanallselectexp[mean_BM_I]

  tmmo_adaptive_AB_exp<-tmallselectexp[tm_BM_I]

  varmo_adaptive_AB_exp<-varallselectexp[var_BM_I]

  fmmo_adaptive_AB_exp<-fmallselectexp[fm_BM_I]

  #Weibull

  kurt1<-26

  skew1<-4

  Kappa1_AB<-function(start_kurt1){
    var_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt1,Ilist=standist_I,etype="var_AB_Weibull")

    fm_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt1,Ilist=standist_I,etype="fm_AB_Weibull")

    if(var_BM_I[1]==var_BM_I[2]||length(var_BM_I)==1){
      varmo_adaptive_AB_Weibull<-varallselectWeibull[var_BM_I[1]]
    }else{
      varmo_adaptive_AB_Weibull1<-varallselectWeibull[var_BM_I[1]]
      varmo_adaptive_AB_Weibull2<-varallselectWeibull[var_BM_I[2]]

      varmo_adaptive_AB_Weibull<-(((varmo_adaptive_AB_Weibull2-varmo_adaptive_AB_Weibull1)*((start_kurt-var_BM_I[3])/(var_BM_I[4]-var_BM_I[3])))+varmo_adaptive_AB_Weibull1)

    }

    if(fm_BM_I[1]==fm_BM_I[2]||length(fm_BM_I)==1){
      fmmo_adaptive_AB_Weibull<-fmallselectWeibull[fm_BM_I[1]]
    }else{
      fmmo_adaptive_AB_Weibull1<-fmallselectWeibull[fm_BM_I[1]]
      fmmo_adaptive_AB_Weibull2<-fmallselectWeibull[fm_BM_I[2]]

      fmmo_adaptive_AB_Weibull<-(((fmmo_adaptive_AB_Weibull2-fmmo_adaptive_AB_Weibull1)*((start_kurt-fm_BM_I[3])/(fm_BM_I[4]-fm_BM_I[3])))+fmmo_adaptive_AB_Weibull1)

    }

    ((fmmo_adaptive_AB_Weibull))/(varmo_adaptive_AB_Weibull^2)
  }
  step1 <- 0

  repeat {
    step1 <-step1 + 1

    kurt2<-Kappa1_AB(kurt1)

    if ((abs(kurt1-kurt2))<criterion || (step1 == stepsize)){

      break
    }
    kurt1<-kurt2
  }


  Skew1_AB<-function(start_skew1){
    var_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,Ilist=standist_I,etype="var_AB_Weibull")

    tm_BM_I<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew1,Ilist=standist_I,etype="tm_AB_Weibull")

    if(var_BM_I[1]==var_BM_I[2]||length(var_BM_I)==1){
      varmo_adaptive_AB_Weibull<-varallselectWeibull[var_BM_I[1]]
    }else{
      varmo_adaptive_AB_Weibull1<-varallselectWeibull[var_BM_I[1]]
      varmo_adaptive_AB_Weibull2<-varallselectWeibull[var_BM_I[2]]

      varmo_adaptive_AB_Weibull<-(((varmo_adaptive_AB_Weibull2-varmo_adaptive_AB_Weibull1)*((kurt1-var_BM_I[3])/(var_BM_I[4]-var_BM_I[3])))+varmo_adaptive_AB_Weibull1)

    }

    if(tm_BM_I[1]==tm_BM_I[2]||length(tm_BM_I)==1){
      tmmo_adaptive_AB_Weibull<-tmallselectWeibull[tm_BM_I[1]]
    }else{
      tmmo_adaptive_AB_Weibull1<-tmallselectWeibull[tm_BM_I[1]]
      tmmo_adaptive_AB_Weibull2<-tmallselectWeibull[tm_BM_I[2]]

      tmmo_adaptive_AB_Weibull<-(((tmmo_adaptive_AB_Weibull2-tmmo_adaptive_AB_Weibull1)*((start_skew-tm_BM_I[3])/(tm_BM_I[4]-tm_BM_I[3])))+tmmo_adaptive_AB_Weibull1)

    }

    ((tmmo_adaptive_AB_Weibull))/(varmo_adaptive_AB_Weibull^(3/2))
  }

  step1 <- 0

  repeat {
    step1 <-step1 + 1

    skew2<-Skew1_AB(skew1)

    if ((abs(skew1-skew2))<criterion || (step1 == stepsize)){

      break
    }
    skew1<-skew2
  }

  mean_BM_I<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,Ilist=standist_I,etype="mean_AB_Weibull")

  if(mean_BM_I[1]==mean_BM_I[2]||length(mean_BM_I)==1){
    mean_adaptive_AB_Weibull<-meanallselectWeibull[mean_BM_I[1]]
  }else{
    mean_adaptive_AB_Weibull1<-meanallselectWeibull[mean_BM_I[1]]
    mean_adaptive_AB_Weibull2<-meanallselectWeibull[mean_BM_I[2]]

    mean_adaptive_AB_Weibull<-(((mean_adaptive_AB_Weibull2-mean_adaptive_AB_Weibull1)*((skew1-mean_BM_I[3])/(mean_BM_I[4]-mean_BM_I[3])))+mean_adaptive_AB_Weibull1)

  }

  var_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,Ilist=standist_I,etype="var_AB_Weibull")

  if(var_BM_I[1]==var_BM_I[2]||length(var_BM_I)==1){
    varmo_adaptive_AB_Weibull<-varallselectWeibull[var_BM_I[1]]
  }else{
    varmo_adaptive_AB_Weibull1<-varallselectWeibull[var_BM_I[1]]
    varmo_adaptive_AB_Weibull2<-varallselectWeibull[var_BM_I[2]]

    varmo_adaptive_AB_Weibull<-(((varmo_adaptive_AB_Weibull2-varmo_adaptive_AB_Weibull1)*((kurt1-var_BM_I[3])/(var_BM_I[4]-var_BM_I[3])))+varmo_adaptive_AB_Weibull1)

  }

  tm_BM_I<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,Ilist=standist_I,etype="tm_AB_Weibull")

  if(tm_BM_I[1]==tm_BM_I[2]||length(tm_BM_I)==1){
    tmmo_adaptive_AB_Weibull<-tmallselectWeibull[tm_BM_I[1]]
  }else{
    tmmo_adaptive_AB_Weibull1<-tmallselectWeibull[tm_BM_I[1]]
    tmmo_adaptive_AB_Weibull2<-tmallselectWeibull[tm_BM_I[2]]

    tmmo_adaptive_AB_Weibull<-(((tmmo_adaptive_AB_Weibull2-tmmo_adaptive_AB_Weibull1)*((skew1-tm_BM_I[3])/(tm_BM_I[4]-tm_BM_I[3])))+tmmo_adaptive_AB_Weibull1)

  }

  fm_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,Ilist=standist_I,etype="fm_AB_Weibull")

  if(fm_BM_I[1]==fm_BM_I[2]||length(fm_BM_I)==1){
    fmmo_adaptive_AB_Weibull<-fmallselectWeibull[fm_BM_I[1]]
  }else{
    fmmo_adaptive_AB_Weibull1<-fmallselectWeibull[fm_BM_I[1]]
    fmmo_adaptive_AB_Weibull2<-fmallselectWeibull[fm_BM_I[2]]

    fmmo_adaptive_AB_Weibull<-(((fmmo_adaptive_AB_Weibull2-fmmo_adaptive_AB_Weibull1)*((kurt1-fm_BM_I[3])/(fm_BM_I[4]-fm_BM_I[3])))+fmmo_adaptive_AB_Weibull1)

  }


  #exp
  start_kurt=9
  start_skew=2

  mean_BM_I<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,Ilist=standist_I,etype="mean_SSE_exp")
  var_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,Ilist=standist_I,etype="var_SSE_exp")
  tm_BM_I<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew,Ilist=standist_I,etype="tm_SSE_exp")
  fm_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt,Ilist=standist_I,etype="fm_SSE_exp")

  meanmo_adaptive_SE_exp<-meanallselectexp[mean_BM_I]

  tmmo_adaptive_SE_exp<-tmallselectexp[tm_BM_I]

  varmo_adaptive_SE_exp<-varallselectexp[var_BM_I]

  fmmo_adaptive_SE_exp<-fmallselectexp[fm_BM_I]

  #Weibull

  kurt1<-26

  skew1<-4


  Kappa1_SE<-function(start_kurt1){
    var_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt1,Ilist=standist_I,etype="var_SSE_Weibull")

    fm_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=start_kurt1,Ilist=standist_I,etype="fm_SSE_Weibull")

    if(var_BM_I[1]==var_BM_I[2]||length(var_BM_I)==1){
      varmo_adaptive_SE_Weibull<-varallselectWeibull[var_BM_I[1]]
    }else{
      varmo_adaptive_SE_Weibull1<-varallselectWeibull[var_BM_I[1]]
      varmo_adaptive_SE_Weibull2<-varallselectWeibull[var_BM_I[2]]

      varmo_adaptive_SE_Weibull<-(((varmo_adaptive_SE_Weibull2-varmo_adaptive_SE_Weibull1)*((start_kurt-var_BM_I[3])/(var_BM_I[4]-var_BM_I[3])))+varmo_adaptive_SE_Weibull1)

    }

    if(fm_BM_I[1]==fm_BM_I[2]||length(fm_BM_I)==1){
      fmmo_adaptive_SE_Weibull<-fmallselectWeibull[fm_BM_I[1]]
    }else{
      fmmo_adaptive_SE_Weibull1<-fmallselectWeibull[fm_BM_I[1]]
      fmmo_adaptive_SE_Weibull2<-fmallselectWeibull[fm_BM_I[2]]

      fmmo_adaptive_SE_Weibull<-(((fmmo_adaptive_SE_Weibull2-fmmo_adaptive_SE_Weibull1)*((start_kurt-fm_BM_I[3])/(fm_BM_I[4]-fm_BM_I[3])))+fmmo_adaptive_SE_Weibull1)

    }

    ((fmmo_adaptive_SE_Weibull))/(varmo_adaptive_SE_Weibull^2)
  }
  step1 <- 0

  repeat {
    step1 <-step1 + 1

    kurt2<-Kappa1_SE(kurt1)

    if ((abs(kurt1-kurt2))<criterion || (step1 == stepsize)){

      break
    }
    kurt1<-kurt2
  }


  Skew1_SE<-function(start_skew1){
    var_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,Ilist=standist_I,etype="var_SSE_Weibull")

    tm_BM_I<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=start_skew1,Ilist=standist_I,etype="tm_SSE_Weibull")

    if(var_BM_I[1]==var_BM_I[2]||length(var_BM_I)==1){
      varmo_adaptive_SE_Weibull<-varallselectWeibull[var_BM_I[1]]
    }else{
      varmo_adaptive_SE_Weibull1<-varallselectWeibull[var_BM_I[1]]
      varmo_adaptive_SE_Weibull2<-varallselectWeibull[var_BM_I[2]]

      varmo_adaptive_SE_Weibull<-(((varmo_adaptive_SE_Weibull2-varmo_adaptive_SE_Weibull1)*((kurt1-var_BM_I[3])/(var_BM_I[4]-var_BM_I[3])))+varmo_adaptive_SE_Weibull1)

    }

    if(tm_BM_I[1]==tm_BM_I[2]||length(tm_BM_I)==1){
      tmmo_adaptive_SE_Weibull<-tmallselectWeibull[tm_BM_I[1]]
    }else{
      tmmo_adaptive_SE_Weibull1<-tmallselectWeibull[tm_BM_I[1]]
      tmmo_adaptive_SE_Weibull2<-tmallselectWeibull[tm_BM_I[2]]

      tmmo_adaptive_SE_Weibull<-(((tmmo_adaptive_SE_Weibull2-tmmo_adaptive_SE_Weibull1)*((start_skew-tm_BM_I[3])/(tm_BM_I[4]-tm_BM_I[3])))+tmmo_adaptive_SE_Weibull1)

    }

    ((tmmo_adaptive_SE_Weibull))/(varmo_adaptive_SE_Weibull^(3/2))
  }

  step1 <- 0

  repeat {
    step1 <-step1 + 1

    skew2<-Skew1_SE(skew1)

    if ((abs(skew1-skew2))<criterion || (step1 == stepsize)){

      break
    }
    skew1<-skew2
  }

  mean_BM_I<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,Ilist=standist_I,etype="mean_SSE_Weibull")

  if(mean_BM_I[1]==mean_BM_I[2]||length(mean_BM_I)==1){
    mean_adaptive_SE_Weibull<-meanallselectWeibull[mean_BM_I[1]]
  }else{
    mean_adaptive_SE_Weibull1<-meanallselectWeibull[mean_BM_I[1]]
    mean_adaptive_SE_Weibull2<-meanallselectWeibull[mean_BM_I[2]]

    mean_adaptive_SE_Weibull<-(((mean_adaptive_SE_Weibull2-mean_adaptive_SE_Weibull1)*((skew1-mean_BM_I[3])/(mean_BM_I[4]-mean_BM_I[3])))+mean_adaptive_SE_Weibull1)

  }

  var_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,Ilist=standist_I,etype="var_SSE_Weibull")

  if(var_BM_I[1]==var_BM_I[2]||length(var_BM_I)==1){
    varmo_adaptive_SE_Weibull<-varallselectWeibull[var_BM_I[1]]
  }else{
    varmo_adaptive_SE_Weibull1<-varallselectWeibull[var_BM_I[1]]
    varmo_adaptive_SE_Weibull2<-varallselectWeibull[var_BM_I[2]]

    varmo_adaptive_SE_Weibull<-(((varmo_adaptive_SE_Weibull2-varmo_adaptive_SE_Weibull1)*((kurt1-var_BM_I[3])/(var_BM_I[4]-var_BM_I[3])))+varmo_adaptive_SE_Weibull1)

  }

  tm_BM_I<-I_adjust_skew(size=lengthx,dtype=dtype1,skew1=skew1,Ilist=standist_I,etype="tm_SSE_Weibull")

  if(tm_BM_I[1]==tm_BM_I[2]||length(tm_BM_I)==1){
    tmmo_adaptive_SE_Weibull<-tmallselectWeibull[tm_BM_I[1]]
  }else{
    tmmo_adaptive_SE_Weibull1<-tmallselectWeibull[tm_BM_I[1]]
    tmmo_adaptive_SE_Weibull2<-tmallselectWeibull[tm_BM_I[2]]

    tmmo_adaptive_SE_Weibull<-(((tmmo_adaptive_SE_Weibull2-tmmo_adaptive_SE_Weibull1)*((skew1-tm_BM_I[3])/(tm_BM_I[4]-tm_BM_I[3])))+tmmo_adaptive_SE_Weibull1)

  }

  fm_BM_I<-I_adjust_kurt(size=lengthx,dtype=dtype1,kurt1=kurt1,Ilist=standist_I,etype="fm_SSE_Weibull")

  if(fm_BM_I[1]==fm_BM_I[2]||length(fm_BM_I)==1){
    fmmo_adaptive_SE_Weibull<-fmallselectWeibull[fm_BM_I[1]]
  }else{
    fmmo_adaptive_SE_Weibull1<-fmallselectWeibull[fm_BM_I[1]]
    fmmo_adaptive_SE_Weibull2<-fmallselectWeibull[fm_BM_I[2]]

    fmmo_adaptive_SE_Weibull<-(((fmmo_adaptive_SE_Weibull2-fmmo_adaptive_SE_Weibull1)*((kurt1-fm_BM_I[3])/(fm_BM_I[4]-fm_BM_I[3])))+fmmo_adaptive_SE_Weibull1)

  }

  rqmoments<-allresults1

  imoments<-c(meanmo_adaptive_AB_exp=meanmo_adaptive_AB_exp,
    varmo_adaptive_AB_exp=varmo_adaptive_AB_exp,
    tmmo_adaptive_AB_exp=tmmo_adaptive_AB_exp,
    fmmo_adaptive_AB_exp=fmmo_adaptive_AB_exp,

    meanmo_adaptive_AB_Weibull=mean_adaptive_AB_Weibull,
    varmo_adaptive_AB_Weibull=varmo_adaptive_AB_Weibull,
    tmmo_adaptive_AB_Weibull=tmmo_adaptive_AB_Weibull,
    fmmo_adaptive_AB_Weibull=fmmo_adaptive_AB_Weibull,

    meanmo_adaptive_SSE_exp=meanmo_adaptive_SE_exp,
    varmo_adaptive_SSE_exp=varmo_adaptive_SE_exp,
    tmmo_adaptive_SSE_exp=tmmo_adaptive_SE_exp,
    fmmo_adaptive_SSE_exp=fmmo_adaptive_SE_exp,

    meanmo_adaptive_SSE_Weibull=mean_adaptive_SE_Weibull,
    varmo_adaptive_SSE_Weibull=varmo_adaptive_SE_Weibull,
    tmmo_adaptive_SSE_Weibull=tmmo_adaptive_SE_Weibull,
    fmmo_adaptive_SSE_Weibull=fmmo_adaptive_SE_Weibull
  )
  if(releaseall){
    finallall<-c(mmm1raw=mmm1raw,
                 varmoraw=varmoraw,
                 tmmoraw=tmmoraw,
                 fmmoraw=fmmoraw,
                 sdall=sdall)
    return(c(rqmoments,finallall,imoments))
  }else{
    return(c(imoments[13:16]))
  }
}

istandardizedmoments<-function (x,dtype1=1,standist_d=NULL,standist_I=NULL,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,interval=8,batch="auto",stepsize=1000,criterion=1e-30,boot=TRUE){
imoments1<-imoments(x=x,dtype1=dtype1,releaseall=FALSE,standist_d=standist_d,standist_I=standist_I,orderlist1_sorted2=orderlist1_sorted2,orderlist1_sorted3=orderlist1_sorted3,orderlist1_sorted4=orderlist1_sorted4,interval=interval,batch=batch,stepsize=stepsize,criterion=criterion,boot=boot)
names(imoments1)<-NULL
istandardizedmoments1<-c(imean=imoments1[1],ivar=imoments1[2],iskew=imoments1[3]/((imoments1[2])^(3/2)),ikurt=imoments1[4]/((imoments1[2])^2))
istandardizedmoments1
}
