#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

compalld<-function (allSWA){
  as.data.frame(compd(expectanalytic=allSWA[1],expecttrue=allSWA[2],expectboot=allSWA[3],SWA1=allSWA[4],median1=allSWA[5],mx1=allSWA[6],quatileexpectanalytic=allSWA[7],
        quatileexpecttrue=allSWA[8],quatileexpectboot=allSWA[9]))
}

compalld_single<-function (target,samplemoments,SWAall,sortedx){
  BM38<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[2],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dBM38<-compalld(BM38)

  sqm8<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[3],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dsqm8<-compalld(sqm8)

  BM28<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[4],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dBM28<-compalld(BM28)

  wm8<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[5],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dwm8<-compalld(wm8)

  bwm8<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[6],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dbwm8<-compalld(bwm8)

  tm8<-compdmmm(expectanalytic=target,expecttrue=samplemoments,x=sortedx,SWA=SWAall[7],median=SWAall[8],isboot=TRUE,sorted=TRUE)

  dtm8<-compalld(tm8)

  all<-c(BM38=BM38,sqm8=sqm8,BM28=BM28,wm8=wm8,bwm8=bwm8,tm8=tm8
  )
  dall<-c(dBM38=dBM38,dsqm8=dsqm8,dBM28=dBM28,dwm8=dwm8,dbwm8=dbwm8,dtm8=dtm8)
  list(all=all,dall=dall)
}

compalldmoments<-function (x,targetm,targetvar,targettm,targetfm,orderlist1_sorted2=NULL,orderlist1_sorted3=NULL,orderlist1_sorted4=NULL,interval=8,batch="auto",boot=TRUE){
  sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)

  lengthx<-length(sortedx)

  samplemoments<-(unbiasedmoments(sortedx))

  SWAmmm<-SWA(x=sortedx,interval=8,batch="auto",sorted=TRUE)

  meand1<-compalld_single(target=targetm,samplemoments=samplemoments[1],SWA=SWAmmm,sortedx=sortedx)

  if(lengthx>40 || boot){

  bootstrappedsample2<-bootbatch1(orderlist11 = orderlist1_sorted2,sortedx=sortedx,dimension=2)

  dp2varx<-varapply1(bootstrappedsample2)
  dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  SWAvar<-SWA(x=dp2varx,interval=8,batch="auto",sorted=TRUE)

  vard1<-compalld_single(target=targetvar,samplemoments=samplemoments[2],SWA=SWAvar,sortedx=dp2varx)

  bootstrappedsample2<-c()
  orderlist1_sorted2<-c()
  dp2varx<-c()

  bootstrappedsample3<-bootbatch1(orderlist11=orderlist1_sorted3,sortedx=sortedx,dimension=3)
  dp3tmx<-tmapply1(bootstrappedsample3)
  dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  SWAtm<-SWA(x=dp3tmx,interval=8,batch="auto",sorted=TRUE)

  tmd1<-compalld_single(target=targettm,samplemoments=samplemoments[3],SWA=SWAtm,sortedx=dp3tmx)

  bootstrappedsample3<-c()
  orderlist1_sorted3<-c()
  dp3tmx<-c()

  bootstrappedsample4<-bootbatch1(orderlist11 = orderlist1_sorted4,sortedx=sortedx,dimension=4)
  dp4tmx<-fmapply1(bootstrappedsample4)
  dp4tmx<-Rfast::Sort(x=dp4tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  SWAfm<-SWA(x=dp4tmx,interval=8,batch="auto",sorted=TRUE)

  fmd1<-compalld_single(target=targetfm,samplemoments=samplemoments[4],SWA=SWAfm,sortedx=dp4tmx)

  bootstrappedsample4<-c()
  orderlist1_sorted4<-c()
  dp4tmx<-c()

  }else{

    combinationsample2<-t(as.data.frame(Rfast::comb_n(sortedx,2)))

    dp2varx<-varapply1(combinationsample2)
    dp2varx<-Rfast::Sort(x=dp2varx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    SWAvar<-SWA(x=dp2varx,interval=8,batch="auto",sorted=TRUE)

    vard1<-compalld_single(target=targetvar,samplemoments=samplemoments[2],SWA=SWAvar,sortedx=dp2varx)

    combinationsample2<-c()
    orderlist1_sorted2<-c()
    dp2varx<-c()

    combinationsample3<-t(as.data.frame(Rfast::comb_n(sortedx,3)))

    dp3tmx<-tmapply1(combinationsample3)
    dp3tmx<-Rfast::Sort(x=dp3tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    SWAtm<-SWA(x=dp3tmx,interval=8,batch="auto",sorted=TRUE)

    tmd1<-compalld_single(target=targettm,samplemoments=samplemoments[3],SWA=SWAtm,sortedx=dp3tmx)

    combinationsample3<-c()
    orderlist1_sorted3<-c()
    dp3tmx<-c()

    combinationsample4<-t(as.data.frame(Rfast::comb_n(sortedx,4)))

    dp4tmx<-fmapply1(combinationsample4)
    dp4tmx<-Rfast::Sort(x=dp4tmx,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
    SWAfm<-SWA(x=dp4tmx,interval=8,batch=1,sorted=TRUE)

    fmd1<-compalld_single(target=targetfm,samplemoments=samplemoments[4],SWA=SWAfm,sortedx=dp4tmx)

    combinationsample4<-c()
    orderlist1_sorted4<-c()
    dp4tmx<-c()

  }
  mean1<-meand1$all
  var1<-vard1$all
  tm1<-tmd1$all
  fm1<-fmd1$all

  all1<-c(mean1=mean1,var1=var1,tm1=tm1,fm1=fm1)
  dall1<-cbind(meand1=as.data.frame(meand1$dall),vard1=as.data.frame(vard1$dall),tmd1=as.data.frame(tmd1$dall),fmd1=as.data.frame(fmd1$dall))
  allcombine<-unlist(c(dall1,all1))
  return(allcombine)
}

