#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

compdmmm<-function(expectanalytic,expecttrue,x,SWA,median,isboot=TRUE,sorted=FALSE){
  if(sorted){
    sortedx<-x
  }else{
    sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)

  quatileexpectanalytic<-CDF(x=sortedx,xevaluated=expectanalytic,sorted=TRUE)
  quatileexpecttrue<-CDF(x=sortedx,xevaluated=expecttrue,sorted=TRUE)
  if(isboot){
    expectboot=matrixStats::mean2(x)
    quatileexpectboot<-CDF(x=sortedx,xevaluated=expectboot,sorted=TRUE)
  }else{
    expectboot=expecttrue
    quatileexpectboot<-quatileexpecttrue
  }
  mx1<-CDF(x=sortedx,xevaluated=SWA,sorted=TRUE)
  listd<-c(expectanalytic=expectanalytic,expecttrue=expecttrue,expectboot=expectboot,SWA=SWA,median=median,mx1=mx1,quatileexpectanalytic=quatileexpectanalytic,quatileexpecttrue=quatileexpecttrue,quatileexpectboot=quatileexpectboot)
  (listd)
}

