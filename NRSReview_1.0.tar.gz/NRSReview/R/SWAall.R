#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

SWAall<-function(x,IntKsamples,target1,sorted=FALSE){
  if(sorted){
    x_ordered<-x
  }else{
    x_ordered<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  if ((target1/IntKsamples)==8){

    intervalsum1<-intervalsum(x_ordered=x_ordered,IntKsamples=IntKsamples,target1=target1,interval=8)

    names(intervalsum1)<-NULL

    sumlist1<-intervalsum1[1]
    sumlist2<-intervalsum1[2]
    sumlist3<-intervalsum1[3]
    sumlist4<-intervalsum1[4]

    median1<-mediansorted(sortedx=x_ordered,lengthx=target1)
    names(median1)<-NULL
    tm8<-(sumlist2+sumlist3+sumlist4)/(IntKsamples*(6))

    winsor<-(c(x_ordered[(IntKsamples+1)],x_ordered[(((target1-IntKsamples)))]))

    winsor1<-sum(winsor)*IntKsamples

    wm8<-(tm8*IntKsamples*(6)+winsor1)/(IntKsamples*(8))

    bwm8<-(tm8*IntKsamples*(6)+sumlist2)/(IntKsamples*(8))

    sq8<-c(quantilefunction(x=x_ordered,quatiletarget=1/8,sorted=TRUE),quantilefunction(x=x_ordered,quatiletarget=3/8,sorted=TRUE),quantilefunction(x=x_ordered,quatiletarget=5/8,sorted=TRUE),quantilefunction(x=x_ordered,quatiletarget=7/8,sorted=TRUE))

    sqm8<-sum(sq8)/4

    BM28<-(sumlist2+sumlist3)/(IntKsamples*(4))

    BM38<-(sumlist2*4-2*sumlist3+2*sumlist4)/(IntKsamples*(8))

    mean1<-(sumlist1+sumlist2+sumlist3+sumlist4)/(IntKsamples*(8))

    Groupmean<-c(mean1=mean1,BM38=BM38,sqm8=sqm8,BM28=BM28,wm8=wm8,bwm8=bwm8,tm8=tm8,median1=median1)

    return(Groupmean)
  }
  else{
    return("Not supported yet.")
  }
}

rqm<-function(x,sorted=FALSE){
  if(sorted){
    x_ordered<-x
  }else{
    x_ordered<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  mmm1raw<-mmmraw(x=x_ordered)
  
  mmm1_BM_rm_exp1<-mmmprocessrm(x=x_ordered,interval=8,SWA=mmm1raw[2],median=mmm1raw[8],mx1=mmm1raw[9],drm=0.37523)
  
  mmm1_BM_qm_exp1<-mmmprocessqm(x=x_ordered,interval=8,SWA=mmm1raw[2],median=mmm1raw[8],mx1=mmm1raw[9],dqm=0.32128)
  
  c(mmm1_BM_rm_exp1,mmm1_BM_qm_exp1)
}

midhinge<-function(x,sorted=FALSE){
  if(sorted){
    x_ordered<-x
  }else{
    x_ordered<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  sq4<-c(quantilefunction(x=x_ordered,quatiletarget=1/4,sorted=TRUE),quantilefunction(x=x_ordered,quatiletarget=3/4,sorted=TRUE))
  
  c(midhinge=sum(sq4)/2)
}