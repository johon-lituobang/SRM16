#include <Rcpp.h>
using namespace Rcpp;
/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it.
 */

double getvar(NumericVector x) {
  return pow(x[0] - x[1], 2) / 2;
}

// [[Rcpp::export]]
NumericVector varapply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = getvar(mat.row(i));
  }
  return out;
}

double gettm(NumericVector x) {
  double res = ((1.0/6.0)*(2*x[0]-x[1]-x[2])*(-1*x[0]+2*x[1]-x[2])*(-x[0]-x[1]+2*x[2]));
  return res;
}

// [[Rcpp::export]]
NumericVector tmapply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gettm(mat.row(i));
  }
  return out;
}

double getfm(NumericVector x) {
  double res = ((1.0/12.0)*(3*pow(x[0],4)+3*pow(x[1],4)+3*pow(x[2],4)+6*pow(x[1],2)*x[2]*x[3]-4*pow(x[2],3)*x[3]-
                4*x[2]*pow(x[3],3)+3*pow(x[3],4)-4*pow(x[1],3)*(x[2]+x[3])-4*pow(x[0],3)*(x[1]+x[2]+x[3])+
                x[1]*(-4*pow(x[2],3)+6*pow(x[2],2)*x[3]+6*x[2]*pow(x[3],2)-4*pow(x[3],3))+
                6*pow(x[0],2)*((x[2] * x[3]) + x[1] * (x[2] +x[3])) +
                x[0] *(-4*pow(x[1],3)-4*pow(x[2],3)+6*pow(x[2],2)*x[3]+6*pow(x[3], 2)*x[2]-4 * pow(x[3], 3)+
                6*pow(x[1], 2)*(x[2]+x[3])+6*(x[1])*(pow(x[2], 2)-6*x[3]*(x[2])+pow(x[3], 2)
                ))));
  return res;
}

// [[Rcpp::export]]
NumericVector fmapply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = getfm(mat.row(i));
  }
  return out;
}


double gethl(NumericVector x) {
  return (x[0] + x[1])/2;
}

// [[Rcpp::export]]
NumericVector hlapply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl(mat.row(i));
  }
  return out;
}

double gethl3(NumericVector x) {
  return (x[0] + x[1] + x[2])/3;
}

// [[Rcpp::export]]
NumericVector hl3apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl3(mat.row(i));
  }
  return out;
}


double gethl4(NumericVector x) {
  return (x[0] + x[1] + x[2] + x[3])/4;
}

// [[Rcpp::export]]
NumericVector hl4apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl4(mat.row(i));
  }
  return out;
}


double gethl5(NumericVector x) {
  return (x[0] + x[1] + x[2] + x[3] + x[4])/5;
}

// [[Rcpp::export]]
NumericVector hl5apply1(NumericMatrix mat) {
  int n = mat.nrow();
  NumericVector out(n);
  for (int i = 0; i < n; ++i) {
    out[i] = gethl5(mat.row(i));
  }
  return out;
}


/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it in any conditions.
 */
