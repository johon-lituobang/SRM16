#include <Rcpp.h>
using namespace Rcpp;
/*
 Copyright 2023 Tuban Lee
 This is a test code that is currently under review in PNAS, please do not share it.
 */

// [[Rcpp::export]]
List moments(NumericVector x) {
  int n = x.size();
  double m1 = mean(x);
  double var1 = sum(pow(x - m1, 2)) / n;
  double tm1 = sum(pow(x - m1, 3)) / n;
  double fm1 = sum(pow(x - m1, 4)) / n;
  return List::create(Named("mean") = m1,
                      Named("var") = var1,
                      Named("tm") = tm1,
                      Named("fm") = fm1);
}
